function nn = Multinomial_numitems(qq);
% nn = numitems(qq)
% returns number of data items in component qq.

nn = qq.nn;

