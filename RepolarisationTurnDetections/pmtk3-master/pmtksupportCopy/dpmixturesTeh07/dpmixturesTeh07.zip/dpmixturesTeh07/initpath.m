global base
base = [pwd '/'];
addpath([base 'distributions']);
addpath([base 'utilities']);
addpath([base 'finitemixture']);
addpath([base 'dpmixture']);
addpath([base 'talkdemo']);
addpath([base 'nipsdata']);


